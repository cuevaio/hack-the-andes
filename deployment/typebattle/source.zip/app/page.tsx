'use client';

import {useEffect,useRef,useState} from 'react';
import {z} from 'zod';
import {battleSchema,duration,raceMetrics,evaluateTyping,type Battle} from './race';

const errorSchema=z.object({error:z.string()});
const pongSchema=z.object({type:z.literal('pong'),sentAt:z.number(),serverNow:z.number()});

export default function Arena(){
 const [battle,setBattle]=useState<Battle>({round:1,passage:'',startAt:null,endedAt:null,now:0,players:[],joined:false,isAdmin:false});
 const [clock,setClock]=useState(0);
 const [connected,setConnected]=useState(false);
 const [latency,setLatency]=useState<number|null>(null);
 const [name,setName]=useState('');
 const [typed,setTyped]=useState('');
 const [strokes,setStrokes]=useState(0);
 const [error,setError]=useState('');
 const [hostDialog,setHostDialog]=useState(false);
 const [password,setPassword]=useState('');
 const [busy,setBusy]=useState(false);
 const input=useRef<HTMLTextAreaElement>(null);
 const passageBox=useRef<HTMLDivElement>(null);
 const socket=useRef<WebSocket|null>(null);
 const reconnect=useRef<()=>void>(()=>{});
 const offset=useRef(0);
 const round=useRef<number|null>(null);
 const draft=useRef({text:'',strokes:0});
 const bestRtt=useRef(Infinity);
 const localFinishedAt=useRef<number|null>(null);

 useEffect(()=>{
  let stopped=false;
  let retry:ReturnType<typeof setTimeout>;
  let ws:WebSocket;
  function connect(){
   if(stopped)return;
   ws=new WebSocket(`${location.protocol==='https:'?'wss:':'ws:'}//${location.host}/ws`);
   socket.current=ws;
   bestRtt.current=Infinity;let needsResend=true;
   ws.onopen=()=>{setConnected(true);setError('');ws.send(JSON.stringify({type:'ping',sentAt:Date.now()}));};
   ws.onmessage=event=>{
    try{
     const message:unknown=JSON.parse(event.data);
     const pong=pongSchema.safeParse(message);
     if(pong.success){const received=Date.now(),rtt=received-pong.data.sentAt;setLatency(rtt);if(rtt<=bestRtt.current){bestRtt.current=rtt;offset.current=pong.data.serverNow-(pong.data.sentAt+received)/2;}return;}
     const failure=errorSchema.safeParse(message);
     if(failure.success){setError(failure.data.error);return;}
     const state=battleSchema.parse(message);
     if(round.current!==null&&round.current!==state.round){
      setTyped('');setStrokes(0);draft.current={text:'',strokes:0};localFinishedAt.current=null;setError('');
     }
     round.current=state.round;
     if(bestRtt.current===Infinity)offset.current=state.now-Date.now();
     setBattle(state);setClock(Date.now()+offset.current);
     if(needsResend){needsResend=false;const player=state.players.find(p=>p.id==='you');if((draft.current.text||draft.current.strokes>0)&&player&&player.finished_at===null&&state.startAt!==null&&state.endedAt===null&&state.now>=state.startAt&&state.now<state.startAt+duration*1000)ws.send(JSON.stringify({action:'progress',round:state.round,...draft.current}));}
    }catch{setError('Connection interrupted. Reconnecting.');ws.close();}
   };
   ws.onclose=()=>{setConnected(false);if(!stopped)retry=setTimeout(connect,750)};
   ws.onerror=()=>ws.close();
  }
  reconnect.current=()=>{clearTimeout(retry);if(ws){ws.onclose=null;ws.onmessage=null;ws.onerror=null;ws.onopen=null;ws.close();}connect()};
  connect();
  const probes=setInterval(()=>{if(socket.current?.readyState===WebSocket.OPEN)socket.current.send(JSON.stringify({type:'ping',sentAt:Date.now()}))},5000);
  const tick=setInterval(()=>setClock(Date.now()+offset.current),100);
  return()=>{stopped=true;clearTimeout(retry);clearInterval(tick);clearInterval(probes);ws?.close()};
 },[]);

 const passage=battle.passage;
 const start=battle.startAt;
 const phase=start===null?'lobby':clock<start?'countdown':battle.endedAt===null&&clock<start+duration*1000?'racing':'finished';
 const remaining=phase==='finished'?0:start?Math.max(0,Math.ceil((start+duration*1000-clock)/1000)):duration;
 const countdown=start?Math.max(0,Math.ceil((start-clock)/1000)):5;
 const me=battle.players.find(p=>p.id==='you');
 const done=(me?.finished_at!==null&&me?.finished_at!==undefined)||localFinishedAt.current!==null;
 const scoreTime=Math.min(clock,battle.endedAt??Infinity);
 const preview=(phase==='racing'||localFinishedAt.current!==null)&&me&&me.finished_at===null&&(typed.length>0||strokes>0)?{...me,...evaluateTyping(typed,strokes,passage),finished_at:me.finished_at??localFinishedAt.current}:me;
 const metrics=preview?raceMetrics(preview,start,scoreTime):{accuracy:1,netWpm:0};
 const wpm=Math.round(metrics.netWpm);
 const accuracy=Math.round(metrics.accuracy*1000)/10;
 const personalFinish=preview?.finished_at??null;
 const elapsed=start===null?0:Math.max(0,(Math.min(personalFinish??scoreTime,start+duration*1000)-start)/1000);
 const rank=battle.players.findIndex(p=>p.id==='you')+1;

 useEffect(()=>{if(phase==='racing'&&battle.joined)input.current?.focus()},[phase,battle.joined,battle.round]);
 useEffect(()=>{
  const box=passageBox.current;
  const current=box?.querySelector('.current');
  if(box&&current){box.scrollTop+=current.getBoundingClientRect().top-box.getBoundingClientRect().top-box.clientHeight/2;}
 },[typed]);

 async function action(body:object){
  setError('');setBusy(true);
  try{
   const response=await fetch('/api/battle',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
   if(!response.ok)throw Error(errorSchema.parse(await response.json()).error);
   if('action' in body&&(body.action==='join'||body.action==='admin'))reconnect.current();return true;
  }catch(failure){setError(failure instanceof Error?failure.message:'Connection lost. Try again.');return false;}
  finally{setBusy(false);}
 }

 return <main className="arena">
  <header className="header">
   <a className="wordmark" href="/">typebattle<span>.</span></a>
   <div className="header-actions"><span className={'connection '+(connected?'online':'')}><i/>{connected?`Live${latency===null?'':` · ${latency} ms`}`:'Reconnecting'}</span>
    {!battle.isAdmin&&<button className="text-button" onClick={()=>{setError('');setHostDialog(true)}}>Host access</button>}
   </div>
  </header>

  <section className="race-heading">
   <div><h1>{phase==='finished'?'Race complete':phase==='racing'?'Race on':phase==='countdown'?'Get ready':'Typing battle'}</h1>
    <p>{battle.players.length}/100 players <span>·</span> {passage.length} characters <span>·</span> 90 seconds</p>
   </div>
   {battle.isAdmin&&<div className="host-controls"><span>Host</span>
    <button className="primary" disabled={busy||!connected||phase!=='lobby'||!battle.players.length} onClick={()=>action({action:'start'})}>Start race</button>
    <button disabled={busy||!connected||phase!=='racing'} onClick={()=>action({action:'finish'})}>Finish race</button>
    <button disabled={busy||!connected||phase==='lobby'} title="Clear scores and return everyone to the lobby. Players stay joined." onClick={()=>action({action:'restart'})}>Restart</button>
   </div>}
  </section>

  {error&&<div className="error" role="alert">{error}<button aria-label="Dismiss error" onClick={()=>setError('')}>×</button></div>}

  <div className={`layout ${phase==='lobby'?'lobby-layout':''}`}>
   <section className="race-panel" aria-label="Race">
    {phase==='lobby'&&<div className="lobby">
     <h2>{battle.joined?"You're in.":'Join the race.'}</h2>
     <p>Waiting for the host to start.</p>
     {!battle.joined&&<form className="join" onSubmit={event=>{event.preventDefault();action({action:'join',name})}}>
      <label className="sr-only" htmlFor="name">Your name</label>
      <input id="name" value={name} maxLength={20} required autoComplete="nickname" placeholder="Your name" onChange={event=>setName(event.target.value)}/>
      <button className="primary" disabled={busy||!connected||battle.players.length>=100}>{battle.players.length>=100?'Lobby full':'Join'}</button>
     </form>}
    </div>}
    {phase==='countdown'&&<div className="countdown"><p>Starting in</p><strong>{countdown}</strong></div>}
    {(phase==='racing'||phase==='finished')&&<>
     <div className="race-meta"><span>{phase==='finished'?'Final results':done?'Finished':battle.joined?'Type the passage':'Spectating'}</span><strong>{remaining}s</strong></div>
     {phase==='finished'?<div className="results"><h2>{battle.players[0]?.name??'Nobody'} wins.</h2><p>{battle.joined?`You placed #${rank} · ${wpm} net WPM · ${elapsed.toFixed(1)}s`:'The final standings are on the leaderboard.'}</p>{battle.isAdmin&&<p className="hint">Restart to return everyone to the lobby.</p>}</div>:<>
      <div className="passage" ref={passageBox}>{passage.split('').map((letter,index)=><span key={index} className={index<typed.length?(letter===typed[index]?'correct':'incorrect'):index===typed.length?'current':''}>{letter}</span>)}</div>
      {battle.joined&&!done&&<textarea ref={input} aria-label="Type the passage" value={typed} maxLength={passage.length} disabled={!connected} autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} placeholder="Start typing…"
       onPaste={event=>{event.preventDefault();setError('Type the passage. Pasting is disabled.')}} onDrop={event=>event.preventDefault()}
       onChange={event=>{const text=event.target.value;if(text.length>typed.length+1)return;const count=strokes+Math.max(0,text.length-typed.length);setTyped(text);setStrokes(count);draft.current={text,strokes:count};if(text.length===passage.length)localFinishedAt.current??=Date.now()+offset.current;const ws=socket.current;if(ws?.readyState===WebSocket.OPEN){ws.send(JSON.stringify({action:'progress',round:round.current,text,strokes:count}));}}}/>}
      {done&&<p className="finished-note" role="status">Your final score: {wpm} net WPM in {elapsed.toFixed(1)}s. Other players are still racing.</p>}
     </>}
     {battle.joined&&<div className="personal-stats"><span><b>{wpm}</b> net WPM</span><span><b>{accuracy}%</b> accuracy</span><span><b>#{rank}</b> place</span></div>}
    </>}
   </section>

   <aside className="leaderboard" aria-label={phase==='lobby'?'Participants in room':'Leaderboard'}>
    <div className="leader-title"><h2>{phase==='lobby'?'Participants in room':'Leaderboard'}</h2><span>{phase==='lobby'?`${battle.players.filter(player=>player.online).length} online`:battle.players.length}</span></div>
    {!battle.players.length&&<p className="empty">No players yet.</p>}
    <ol>{battle.players.map((player,index)=>{
     const score=raceMetrics(player,start,scoreTime);
     return <li className={player.id==='you'?'you':''} key={`${player.name}-${index}`}><span className="position">{index+1}</span><div className="racer"><span>{player.name}{player.id==='you'&&<small>you</small>}</span>{phase!=='lobby'&&<div className="track"><i style={{width:`${Math.min(100,player.progress/passage.length*100)}%`}}/></div>}</div><span className="speed">{phase==='lobby'?(player.online?'Online':'Away'):<>{Math.round(score.netWpm)} wpm<small>{Math.round(score.accuracy*1000)/10}% acc.</small></>}</span></li>;
    })}</ol>
   </aside>
  </div>

  {hostDialog&&<div className="dialog-backdrop" onClick={()=>setHostDialog(false)}><section className="dialog" role="dialog" aria-modal="true" aria-labelledby="host-title" onClick={event=>event.stopPropagation()}>
   <button className="close" aria-label="Close host access" onClick={()=>setHostDialog(false)}>×</button><h2 id="host-title">Host access</h2>
   <form onSubmit={async event=>{event.preventDefault();if(await action({action:'admin',password})){setPassword('');setHostDialog(false)}}}>
    <label htmlFor="password">Passphrase</label><input id="password" autoFocus type="password" value={password} required onChange={event=>setPassword(event.target.value)}/><button className="primary" disabled={busy}>Unlock</button>
   </form>{error&&<p className="dialog-error" role="alert">{error}</p>}
  </section></div>}
 </main>;
}
