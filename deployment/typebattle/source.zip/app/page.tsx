'use client';

import {useEffect,useRef,useState} from 'react';
import {z} from 'zod';
import {battleSchema,duration,passage,type Battle} from './race';

const errorSchema=z.object({error:z.string()});

export default function Arena(){
 const [battle,setBattle]=useState<Battle>({round:1,startAt:null,now:0,players:[],joined:false,isAdmin:false});
 const [clock,setClock]=useState(0);
 const [connected,setConnected]=useState(false);
 const [name,setName]=useState('');
 const [typed,setTyped]=useState('');
 const [strokes,setStrokes]=useState(0);
 const [error,setError]=useState('');
 const [hostDialog,setHostDialog]=useState(false);
 const [password,setPassword]=useState('');
 const [busy,setBusy]=useState(false);
 const input=useRef<HTMLTextAreaElement>(null);
 const passageBox=useRef<HTMLDivElement>(null);
 const socket=useRef<WebSocket|null>(null);
 const reconnect=useRef<()=>void>(()=>{});
 const offset=useRef(0);
 const round=useRef<number|null>(null);
 const draft=useRef({text:'',strokes:0});
 const lastSent=useRef('');

 useEffect(()=>{
  let stopped=false;
  let retry:ReturnType<typeof setTimeout>;
  let ws:WebSocket;
  function connect(){
   if(stopped)return;
   ws=new WebSocket(`${location.protocol==='https:'?'wss:':'ws:'}//${location.host}/ws`);
   socket.current=ws;
   lastSent.current='';
   ws.onopen=()=>{setConnected(true);setError('')};
   ws.onmessage=event=>{
    try{
     const message:unknown=JSON.parse(event.data);
     const failure=errorSchema.safeParse(message);
     if(failure.success){setError(failure.data.error);return;}
     const state=battleSchema.parse(message);
     if(round.current!==null&&round.current!==state.round){
      setTyped('');setStrokes(0);draft.current={text:'',strokes:0};lastSent.current='';setError('');
     }
     round.current=state.round;
     offset.current=state.now-Date.now();
     setBattle(state);setClock(Date.now()+offset.current);
    }catch{setError('Connection interrupted. Reconnecting.');ws.close();}
   };
   ws.onclose=()=>{setConnected(false);if(!stopped)retry=setTimeout(connect,750)};
   ws.onerror=()=>ws.close();
  }
  reconnect.current=()=>ws?.close();
  connect();
  const tick=setInterval(()=>setClock(Date.now()+offset.current),100);
  return()=>{stopped=true;clearTimeout(retry);clearInterval(tick);ws?.close()};
 },[]);

 const start=battle.startAt;
 const phase=start===null?'lobby':clock<start?'countdown':clock<start+duration*1000?'racing':'finished';
 const remaining=start?Math.max(0,Math.ceil((start+duration*1000-clock)/1000)):duration;
 const countdown=start?Math.max(0,Math.ceil((start-clock)/1000)):5;
 const me=battle.players.find(p=>p.id==='you');
 const done=me?.finished_at!==null&&me?.finished_at!==undefined;
 const elapsed=start?Math.max(1,Math.min(duration,((me?.finished_at??clock)-start)/1000)):1;
 const wpm=Math.round((me?.progress??0)/5/(elapsed/60));
 let correct=0;
 while(correct<typed.length&&typed[correct]===passage[correct])correct++;
 const accuracy=strokes?Math.min(100,Math.round(correct/strokes*100)):100;
 const rank=battle.players.findIndex(p=>p.id==='you')+1;

 useEffect(()=>{if(phase==='racing'&&battle.joined)input.current?.focus()},[phase,battle.joined,battle.round]);
 useEffect(()=>{
  if(phase!=='racing'||!battle.joined)return;
  const timer=setInterval(()=>{
   const value=draft.current;
   const ws=socket.current;
   if(value.text===lastSent.current||ws?.readyState!==WebSocket.OPEN)return;
   ws.send(JSON.stringify({action:'progress',round:round.current,...value}));
   lastSent.current=value.text;
  },100);
  return()=>clearInterval(timer);
 },[phase,battle.joined]);
 useEffect(()=>{
  const box=passageBox.current;
  const current=box?.querySelector('.current');
  if(box&&current){box.scrollTop+=current.getBoundingClientRect().top-box.getBoundingClientRect().top-box.clientHeight/2;}
 },[typed]);

 async function action(body:object){
  setError('');setBusy(true);
  try{
   const response=await fetch('/api/battle',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
   if(!response.ok)throw Error(errorSchema.parse(await response.json()).error);
   reconnect.current();return true;
  }catch(failure){setError(failure instanceof Error?failure.message:'Connection lost. Try again.');return false;}
  finally{setBusy(false);}
 }

 return <main className="arena">
  <header className="header">
   <a className="wordmark" href="/">typebattle<span>.</span></a>
   <div className="header-actions"><span className={'connection '+(connected?'online':'')}><i/>{connected?'Live':'Reconnecting'}</span>
    {!battle.isAdmin&&<button className="text-button" onClick={()=>{setError('');setHostDialog(true)}}>Host access</button>}
   </div>
  </header>

  <section className="race-heading">
   <div><h1>{phase==='finished'?'Race complete':phase==='racing'?'Race on':phase==='countdown'?'Get ready':'Typing battle'}</h1>
    <p>{battle.players.length}/100 players <span>·</span> 90 seconds</p>
   </div>
   {battle.isAdmin&&<div className="host-controls"><span>Host</span>
    <button className="primary" disabled={busy||!connected||phase!=='lobby'||!battle.players.length} onClick={()=>action({action:'start'})}>Start race</button>
    <button disabled={busy||!connected||phase==='lobby'} title="Clear scores and return everyone to the lobby. Players stay joined." onClick={()=>action({action:'restart'})}>Restart</button>
   </div>}
  </section>

  {error&&<div className="error" role="alert">{error}<button aria-label="Dismiss error" onClick={()=>setError('')}>×</button></div>}

  <div className="layout">
   <section className="race-panel" aria-label="Race">
    {phase==='lobby'&&<div className="lobby">
     <h2>{battle.joined?"You're in.":'Join the race.'}</h2>
     <p>Waiting for the host to start.</p>
     {!battle.joined&&<form className="join" onSubmit={event=>{event.preventDefault();action({action:'join',name})}}>
      <label className="sr-only" htmlFor="name">Your name</label>
      <input id="name" value={name} maxLength={20} required autoComplete="nickname" placeholder="Your name" onChange={event=>setName(event.target.value)}/>
      <button className="primary" disabled={busy||!connected||battle.players.length>=100}>{battle.players.length>=100?'Lobby full':'Join'}</button>
     </form>}
    </div>}
    {phase==='countdown'&&<div className="countdown"><p>Starting in</p><strong>{countdown}</strong></div>}
    {(phase==='racing'||phase==='finished')&&<>
     <div className="race-meta"><span>{phase==='finished'?'Final results':done?'Finished':battle.joined?'Type the passage':'Spectating'}</span><strong>{remaining}s</strong></div>
     {phase==='finished'?<div className="results"><h2>{battle.players[0]?.name??'Nobody'} wins.</h2><p>{battle.joined?`You placed #${rank} · ${wpm} WPM`:'The final standings are on the leaderboard.'}</p>{battle.isAdmin&&<p className="hint">Restart to return everyone to the lobby.</p>}</div>:<>
      <div className="passage" ref={passageBox}>{passage.split('').map((letter,index)=><span key={index} className={index<typed.length?(letter===typed[index]?'correct':'incorrect'):index===typed.length?'current':''}>{letter}</span>)}</div>
      {battle.joined&&!done&&<textarea ref={input} aria-label="Type the passage" value={typed} disabled={!connected} autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} placeholder="Start typing…"
       onPaste={event=>{event.preventDefault();setError('Type the passage. Pasting is disabled.')}} onDrop={event=>event.preventDefault()}
       onChange={event=>{const text=event.target.value;if(text.length>typed.length+1)return;const count=strokes+Math.max(0,text.length-typed.length);setTyped(text);setStrokes(count);draft.current={text,strokes:count};}}/>}
      {done&&<p className="finished-note">Finished. Waiting for the race to end.</p>}
     </>}
     {battle.joined&&<div className="personal-stats"><span><b>{wpm}</b> WPM</span><span><b>{accuracy}%</b> accuracy</span><span><b>#{rank}</b> place</span></div>}
    </>}
   </section>

   <aside className="leaderboard" aria-label="Leaderboard">
    <div className="leader-title"><h2>Leaderboard</h2><span>{battle.players.length}</span></div>
    {!battle.players.length&&<p className="empty">No players yet.</p>}
    <ol>{battle.players.map((player,index)=>{
     const seconds=start?Math.max(1,((player.finished_at??Math.min(clock,start+duration*1000))-start)/1000):1;
     return <li className={player.id==='you'?'you':''} key={`${player.name}-${index}`}><span className="position">{index+1}</span><div className="racer"><span>{player.name}{player.id==='you'&&<small>you</small>}</span>{phase!=='lobby'&&<div className="track"><i style={{width:`${player.progress/passage.length*100}%`}}/></div>}</div><span className="speed">{phase==='lobby'?'Ready':`${Math.round(player.progress/5/(seconds/60))} wpm`}</span></li>;
    })}</ol>
   </aside>
  </div>

  {hostDialog&&<div className="dialog-backdrop" onClick={()=>setHostDialog(false)}><section className="dialog" role="dialog" aria-modal="true" aria-labelledby="host-title" onClick={event=>event.stopPropagation()}>
   <button className="close" aria-label="Close host access" onClick={()=>setHostDialog(false)}>×</button><h2 id="host-title">Host access</h2>
   <form onSubmit={async event=>{event.preventDefault();if(await action({action:'admin',password})){setPassword('');setHostDialog(false)}}}>
    <label htmlFor="password">Passphrase</label><input id="password" autoFocus type="password" value={password} required onChange={event=>setPassword(event.target.value)}/><button className="primary" disabled={busy}>Unlock</button>
   </form>{error&&<p className="dialog-error" role="alert">{error}</p>}
  </section></div>}
 </main>;
}
