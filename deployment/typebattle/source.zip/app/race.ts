import {z} from 'zod';
export {duration,passage,evaluateTyping,raceMetrics} from '../race.mjs';
export const battleSchema=z.object({
 round:z.number().int(),startAt:z.number().nullable(),now:z.number(),
 players:z.array(z.object({id:z.string().nullable(),name:z.string(),progress:z.number(),correct:z.number(),strokes:z.number(),finished_at:z.number().nullable()})),
 joined:z.boolean(),isAdmin:z.boolean()
});
export type Battle=z.infer<typeof battleSchema>;
