export {duration,passage} from '../race.mjs';
export type Player = { id: string | null; name: string; progress: number; strokes: number; finished_at: number | null };
export type Battle = { startAt: number | null; now: number; players: Player[]; joined: boolean; isAdmin: boolean };
