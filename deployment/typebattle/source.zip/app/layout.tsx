import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = {title:'Typebattle | One arena. One champion.',description:'A live typing battle for 100 players. Join the lobby and race when the host starts.'};
export default function RootLayout({children}:Readonly<{children:React.ReactNode}>) {return <html lang="en"><body>{children}</body></html>}
