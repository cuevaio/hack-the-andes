export const duration = 90;
export const passage = 'Speed is a strange thing. The harder you chase it, the further away it seems. So take a breath. Find your rhythm. Let your fingers settle into the spaces between the words. Somewhere in this room, a hundred people are doing the same thing. Make each word count.';

export function evaluateTyping(text,strokes,target){
 const progress=Math.min(text.length,target.length);
 let correct=0;
 for(let index=0;index<progress;index++)if(text[index]===target[index])correct++;
 return {progress,correct,strokes:Math.max(strokes,text.length)};
}
/** @param {{progress:number,correct:number,strokes:number,finished_at:number|null}} player
 * @param {number|null} startAt
 * @param {number} now */
export function raceMetrics(player,startAt,now){
 const attempts=Math.max(player.strokes,player.progress);
 const accuracy=attempts?player.correct/attempts:1;
 if(startAt===null||now<startAt)return {accuracy,netWpm:0};
 const seconds=Math.max(1,Math.min(duration,((player.finished_at??now)-startAt)/1000));
 return {accuracy,netWpm:player.progress*accuracy/5/(seconds/60)};
}
