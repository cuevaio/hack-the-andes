# Typebattle

A single 100-player typing battle built with Next.js 16, React 19, native WebSockets, and SQLite on Node.js 24. One Node process serves the Next.js app and `/ws`. The host starts a shared five-second countdown followed by a 90-second race. Race state persists in `data/battle.sqlite` across process restarts.

## Run on the VPS

Use Node 24.21.0 and npm with the committed lockfile. Run `npm ci`, `npm run build`, configure `.env.local` using `.env.example`, then `npm start`. The server binds only to `127.0.0.1:3418`. Keep one server process per database; do not use cluster mode or multiple replicas.

`ADMIN_KEY` is server-only. Admin and player cookies are HTTP-only. Public deployment sets secure cookies when `PUBLIC_ORIGIN` is HTTPS. Reverse proxies must support WebSocket upgrades and preserve Origin. See `deploy/Caddyfile` for the intended HTTPS route and `deploy/typebattle.service` for a user-service template. Do not overwrite existing server proxy configuration.

For an SSH preview, forward local port 3418 to the server's 127.0.0.1:3418. Public-origin validation intentionally requires the configured Origin, so use a separate local environment without PUBLIC_ORIGIN for testing.

## Tests

`npm test` tests capacity, start gates, scoring, ranking, persistence, and expiry against real SQLite. `node checks/realtime.mjs` starts an isolated production server with a disposable database, races 110 joins, opens 100 WebSocket clients, starts the race, sends typing progress, and asserts every client sees the final progress. It never modifies the event database.

## Behavior

The server accepts at most 100 players and closes joining when the host starts. Rankings compare correct passage progress, then earliest completed finish. Every join, start, progress update and phase transition broadcasts shared state. Changed typing sends at most ten times per second; broadcasts coalesce over 80 milliseconds. Heartbeat pings detect dead connections, and clients reconnect automatically. There is no leaderboard polling, room creation or reset button.

Browser paste blocking and server-derived prefix scoring support casual races. Modified clients can still automate typing, and clearing cookies can consume another lobby slot. This is not a tamper-proof tournament platform.
