# Typebattle

A single 100-player typing battle built with Next.js 16, React 19, native WebSockets, and SQLite on Node.js 24. One Node process serves the Next.js app and `/ws`. The host starts a shared five-second countdown followed by a 90-second race. Race state persists in `data/battle.sqlite` across process restarts.

## Production

The app runs on the same Dokploy VPS as Hack the Andes, `https://vps.cueva.io` at `85.239.246.19`. The public URL is `https://vibe.hacktheandes.com`. Dokploy application ID: `5rzQb1ZxhxS3hWNyHqbxh`. Its isolated named volume `typebattle-data` persists the single battle database.

Spaceship manages the domain. Doomain credentials are loaded from the user's shell configuration. Dokploy owns HTTPS and the private container network; no application port is published on the host. The Grotte development-server instance is disabled.

## Run locally

Use Node 24.21.0 and npm with the committed lockfile. Run `npm ci`, `npm run build`, configure `.env.local` using `.env.example`, then `npm start`. The server binds only to `127.0.0.1:3418`. Keep one server process per database; do not use cluster mode or multiple replicas.

`ADMIN_KEY` is server-only. Admin and player cookies are HTTP-only. Public deployment sets secure cookies when `PUBLIC_ORIGIN` is HTTPS. Reverse proxies must support WebSocket upgrades and preserve Origin. The Docker image listens on its private container network using `BIND_HOST=0.0.0.0`; Dokploy routes HTTPS internally to port 3418. Local development defaults to `127.0.0.1`.

For an SSH preview, forward local port 3418 to the server's 127.0.0.1:3418. Public-origin validation intentionally requires the configured Origin, so use a separate local environment without PUBLIC_ORIGIN for testing.

## Tests

`npm test` tests capacity, start gates, scoring, ranking, persistence, and expiry against real SQLite. `node checks/realtime.mjs` starts an isolated production server with a disposable database, races 110 joins, opens 100 WebSocket clients, starts the race, sends typing progress, and asserts every client sees the final progress. It never modifies the event database.

## Behavior

The server accepts at most 100 players and closes joining when the host starts. The passage is 261 characters. Progress advances across mistakes. Rankings use net WPM, calculated as typed progress per minute multiplied by accuracy; accuracy is matching characters divided by total keystrokes. Accuracy breaks speed ties. A typo does not invalidate later correct letters. Finishing the passage ends a player's attempt even if some characters are wrong. Every join, start, progress update and phase transition broadcasts shared state. Typing sends immediately, and personal speed and accuracy update locally without waiting for the network. Room broadcasts coalesce over 50 milliseconds, reuse one shared database snapshot, and compress larger messages. Ping/pong probes synchronize clocks and show the connection round-trip time. Heartbeat pings detect dead connections, and clients reconnect automatically. There is no leaderboard polling or room creation. The host-only Restart button clears scores and returns everyone to the lobby while preserving joined players. Start race begins the next countdown. A persisted round number prevents delayed updates from a previous race from changing the new scores. Finish race ends an active battle immediately, freezes scores at a shared persisted end time, and rejects later typing. The pre-race Participants in room list shows joined members as Online or Away and comes first on mobile.

Browser paste blocking and server-derived character scoring support casual races. Modified clients can still automate typing, and clearing cookies can consume another lobby slot. This is not a tamper-proof tournament platform.
