import next from 'next';
import {createServer} from 'node:http';
import {createHash,timingSafeEqual} from 'node:crypto';
import {mkdirSync} from 'node:fs';
import {dirname} from 'node:path';
import {WebSocketServer,WebSocket} from 'ws';
import {z} from 'zod';
import {Race,RaceError} from './engine.mjs';
const host=process.env.BIND_HOST||'127.0.0.1',port=Number(process.env.PORT||3418),dev=process.env.NODE_ENV!=='production';
const data=process.env.DATABASE_PATH||'data/battle.sqlite';mkdirSync(dirname(data),{recursive:true,mode:0o700});
if(!process.env.ADMIN_KEY)throw Error('ADMIN_KEY must be configured.');
const adminToken=createHash('sha256').update(process.env.ADMIN_KEY).digest('hex');
const race=new Race(data);const app=next({dev,hostname:host,port});await app.prepare();const handle=app.getRequestHandler();
const cookies=req=>Object.fromEntries((req.headers.cookie||'').split(';').map(p=>p.trim().split('=')));
function isAdmin(req){const value=cookies(req).host||'';return value.length===adminToken.length&&timingSafeEqual(Buffer.from(value),Buffer.from(adminToken));}
const schema=z.discriminatedUnion('action',[z.object({action:z.literal('join'),name:z.string().trim().min(1).max(20)}),z.object({action:z.literal('admin'),password:z.string().max(200)}),z.object({action:z.literal('start')}),z.object({action:z.literal('restart')}),z.object({action:z.literal('finish')}),z.object({action:z.literal('progress'),round:z.number().int().min(1),text:z.string().max(3000),strokes:z.number().int().min(0).max(20000)})]);
const pingSchema=z.object({type:z.literal('ping'),sentAt:z.number().finite()});
const expectedOrigin=process.env.PUBLIC_ORIGIN;
function validOrigin(req){return req.headers.origin===(expectedOrigin||`http://${req.headers.host}`);}
const failures=new Map();
function json(res,status,body,headers={}){res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store',...headers});res.end(JSON.stringify(body));}
const websocket=new WebSocketServer({noServer:true,maxPayload:16384,perMessageDeflate:{threshold:1024,concurrencyLimit:4,serverNoContextTakeover:true,clientNoContextTakeover:true,zlibDeflateOptions:{level:1}}});
function onlinePlayers(){return new Set([...websocket.clients].filter(ws=>ws.readyState===WebSocket.OPEN).map(ws=>ws.playerId));}
function snapshotFor(id,admin,room=race.roomState(),online=onlinePlayers()){const state=race.snapshot(id,admin,room);return {...state,players:state.players.map((player,index)=>({...player,online:online.has(room.players[index].id)}))};}
let pending;
function broadcast(){if(pending)return;pending=setTimeout(()=>{pending=null;const room=race.roomState(),online=onlinePlayers();for(const client of websocket.clients){if(client.readyState===WebSocket.OPEN){if(client.bufferedAmount>1000000){client.close(1013,'Connection too slow');continue;}client.send(JSON.stringify({type:'state',...snapshotFor(client.playerId,client.admin,room,online)}));}}},50);}
const server=createServer(async(req,res)=>{
 const url=new URL(req.url||'/',`http://${req.headers.host}`);
 if(url.pathname==='/healthz')return json(res,200,{ok:true,transport:'websocket',revision:process.env.APP_REVISION||'development'});
 if(url.pathname!=='/api/battle')return handle(req,res);
 try{
  if(req.method==='GET')return json(res,200,snapshotFor(cookies(req).racer,isAdmin(req)));
  if(req.method!=='POST')return json(res,405,{error:'Method not allowed.'});
  if(!validOrigin(req))return json(res,403,{error:'Invalid request origin.'});
  let raw='';for await(const chunk of req){raw+=chunk;if(raw.length>16384)return json(res,413,{error:'Request too large.'});}
  const b=schema.parse(JSON.parse(raw));let setCookie;const secure=expectedOrigin?.startsWith('https:')?'; Secure':'';
  if(b.action==='admin'){
   const ip=req.socket.remoteAddress;const attempts=failures.get(ip);const now=Date.now();if(attempts&&attempts.until>now&&attempts.count>=10)return json(res,429,{error:'Too many attempts. Try again in a minute.'});
   const candidate=createHash('sha256').update(b.password).digest('hex');if(!timingSafeEqual(Buffer.from(candidate),Buffer.from(adminToken))){failures.set(ip,{count:attempts&&attempts.until>now?attempts.count+1:1,until:now+60000});return json(res,403,{error:'Incorrect passphrase.'});}
   failures.delete(ip);setCookie=`host=${adminToken}; HttpOnly; SameSite=Strict; Path=/; Max-Age=86400${secure}`;
  }else if(b.action==='join'){const id=race.join(b.name,cookies(req).racer);setCookie=`racer=${id}; HttpOnly; SameSite=Strict; Path=/; Max-Age=86400${secure}`;broadcast();}
  else if(b.action==='start'||b.action==='restart'||b.action==='finish'){if(!isAdmin(req))return json(res,403,{error:'Host access required.'});if(b.action==='restart')race.restart();else if(b.action==='finish')race.finish();else race.start();broadcast();}
  else return json(res,400,{error:'Typing progress requires a live WebSocket connection.'});
  return json(res,200,{ok:true},setCookie?{'Set-Cookie':setCookie}:{});
 }catch(e){if(e instanceof RaceError)return json(res,e.status,{error:e.message});if(e instanceof z.ZodError||e instanceof SyntaxError)return json(res,400,{error:'Check your entry and try again.'});console.error(e);return json(res,500,{error:'Server error. Try again.'});}
});
server.on('upgrade',(req,socket,head)=>{
 if(new URL(req.url||'/',`http://${req.headers.host}`).pathname!=='/ws'){if(dev)app.getUpgradeHandler()(req,socket,head);else socket.destroy();return;}
 if(!validOrigin(req)){socket.write('HTTP/1.1 403 Forbidden\r\n\r\n');socket.destroy();return;}
 if(websocket.clients.size>=400){socket.write('HTTP/1.1 503 Service Unavailable\r\n\r\n');socket.destroy();return;}
 websocket.handleUpgrade(req,socket,head,ws=>{ws.playerId=cookies(req).racer;ws.admin=isAdmin(req);ws.alive=true;ws.on('pong',()=>ws.alive=true);ws.on('close',broadcast);ws.send(JSON.stringify({type:'state',...snapshotFor(ws.playerId,ws.admin)}));broadcast();let burst=0;let windowStart=Date.now();ws.on('message',raw=>{if(Date.now()-windowStart>1000){burst=0;windowStart=Date.now();}if(++burst>90){ws.close(1008,'Too many updates');return;}try{const message=JSON.parse(raw.toString());const probe=pingSchema.safeParse(message);if(probe.success){ws.send(JSON.stringify({type:'pong',sentAt:probe.data.sentAt,serverNow:Date.now()}));return;}const b=schema.parse(message);if(b.action!=='progress')throw new RaceError('Unsupported message.',400);race.progress(ws.playerId,b.text,b.strokes,b.round);broadcast();}catch(e){if(e instanceof RaceError&&e.status===409)ws.send(JSON.stringify({type:'state',...snapshotFor(ws.playerId,ws.admin)}));else ws.send(JSON.stringify({type:'error',error:e instanceof RaceError?e.message:'Invalid typing update.'}));}});});
});
let phase='';let lastClockBroadcast=0;const heartbeat=setInterval(()=>{const start=race.startAt(),now=Date.now();const current=start===null?'lobby':now<start?'countdown':race.endedAt()===null&&now<start+90000?'racing':'finished';if(current!==phase||(current==='racing'&&now-lastClockBroadcast>=1000)){phase=current;lastClockBroadcast=now;broadcast();}},100);
const ping=setInterval(()=>{for(const ws of websocket.clients){if(!ws.alive){ws.terminate();continue;}ws.alive=false;ws.ping();}},15000);
server.listen(port,host,()=>console.log(`Typebattle ready at http://${host}:${port}`));
function shutdown(){clearInterval(heartbeat);clearInterval(ping);if(pending)clearTimeout(pending);for(const ws of websocket.clients)ws.close(1001,'Server restarting');websocket.close();server.close(()=>{race.close();process.exit(0);});setTimeout(()=>process.exit(1),5000).unref();}
process.on('SIGTERM',shutdown);process.on('SIGINT',shutdown);
