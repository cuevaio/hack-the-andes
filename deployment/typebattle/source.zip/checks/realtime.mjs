import {spawn} from 'node:child_process';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {once} from 'node:events';
import assert from 'node:assert/strict';
import {WebSocket} from 'ws';
const temp=mkdtempSync(join(tmpdir(),'typebattle-live-'));const origin='http://127.0.0.1:3419';
const server=spawn(process.execPath,['server.mjs'],{env:{...process.env,NODE_ENV:'production',PORT:'3419',ADMIN_KEY:'isolated-test-host',PUBLIC_ORIGIN:origin,DATABASE_PATH:join(temp,'battle.sqlite')},stdio:['ignore','pipe','pipe']});
let output='';server.stdout.on('data',d=>output+=d);server.stderr.on('data',d=>output+=d);const sockets=[];const states=new Map();
async function waitFor(predicate,message,timeout=10000){const deadline=Date.now()+timeout;while(Date.now()<deadline){if(predicate())return;await new Promise(r=>setTimeout(r,20));}throw Error(message+'\n'+output);}
async function post(body,cookie){return fetch(origin+'/api/battle',{method:'POST',headers:{Origin:origin,'Content-Type':'application/json',...(cookie?{Cookie:cookie}:{})},body:JSON.stringify(body)});}
try{
 await waitFor(()=>output.includes('Typebattle ready'),'Server did not start');
 assert.equal((await post({action:'start'})).status,403);
 const joined=await Promise.all(Array.from({length:110},(_,i)=>post({action:'join',name:'Racer '+i})));
 const admitted=joined.filter(r=>r.status===200);assert.equal(admitted.length,100);assert.equal(joined.filter(r=>r.status===409).length,10);
 const cookies=admitted.map(r=>r.headers.get('set-cookie').split(';')[0]);
 await Promise.all(cookies.map(async(cookie,i)=>{const ws=new WebSocket('ws://127.0.0.1:3419/ws',{origin,headers:{Cookie:cookie}});sockets.push(ws);ws.on('message',raw=>{const message=JSON.parse(raw.toString());if(message.type==='state')states.set(ws,message);else throw Error(message.error);});await once(ws,'open');}));
 await waitFor(()=>states.size===100,'100 sockets did not receive initial state');
 const bad=new WebSocket('ws://127.0.0.1:3419/ws',{origin:'https://evil.example'});bad.on('error',()=>{});await new Promise(resolve=>bad.on('close',resolve));
 const login=await post({action:'admin',password:'isolated-test-host'});assert.equal(login.status,200);const hostCookie=login.headers.get('set-cookie').split(';')[0];
 assert.equal((await post({action:'start'},hostCookie)).status,200);
 await waitFor(()=>[...states.values()].every(s=>s.startAt!==null),'Countdown was not pushed to every client');
 const start=[...states.values()][0].startAt;assert.equal(new Set([...states.values()].map(s=>s.startAt)).size,1);
 assert.equal((await post({action:'join',name:'Late'})).status,409);
 await new Promise(r=>setTimeout(r,Math.max(0,start-Date.now()+100)));
 const text='Speed is a strange thing.';const began=Date.now();
 for(let i=1;i<=text.length;i++){for(const ws of sockets)ws.send(JSON.stringify({action:'progress',text:text.slice(0,i),strokes:i}));await new Promise(r=>setTimeout(r,100));}
 await waitFor(()=>[...states.values()].every(s=>s.players.every(p=>p.progress===text.length)),'Progress did not reach all 100 clients');
 assert.equal([...states.values()].every(s=>s.joined),true);
 console.log(`PASS: exactly 100 of 110 joined; 100 live sockets shared countdown and 2,500 progress updates in ${Date.now()-began}ms; unauthorized starts, cross-origin sockets and late joins rejected.`);
}finally{
 for(const ws of sockets)ws.terminate();server.kill('SIGTERM');await once(server,'exit');rmSync(temp,{recursive:true,force:true});
}
