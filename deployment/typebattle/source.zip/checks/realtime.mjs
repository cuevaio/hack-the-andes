import {spawn} from 'node:child_process';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {once} from 'node:events';
import assert from 'node:assert/strict';
import {WebSocket} from 'ws';
const temp=mkdtempSync(join(tmpdir(),'typebattle-live-'));const origin='http://127.0.0.1:3419';
const server=spawn(process.execPath,['server.mjs'],{env:{...process.env,NODE_ENV:'production',PORT:'3419',ADMIN_KEY:'isolated-test-host',PUBLIC_ORIGIN:origin,DATABASE_PATH:join(temp,'battle.sqlite')},stdio:['ignore','pipe','pipe']});
let output='';server.stdout.on('data',d=>output+=d);server.stderr.on('data',d=>output+=d);const sockets=[];const states=new Map();const latencies=[];const sentAt=new Map();const observedProgress=new Map();
async function waitFor(predicate,message,timeout=10000){const deadline=Date.now()+timeout;while(Date.now()<deadline){if(predicate())return;await new Promise(r=>setTimeout(r,20));}throw Error(message+'\n'+output);}
async function post(body,cookie){return fetch(origin+'/api/battle',{method:'POST',headers:{Origin:origin,'Content-Type':'application/json',...(cookie?{Cookie:cookie}:{})},body:JSON.stringify(body)});}
try{
 await waitFor(()=>output.includes('Typebattle ready'),'Server did not start');
 assert.equal((await post({action:'start'})).status,403);
 const joined=await Promise.all(Array.from({length:110},(_,i)=>post({action:'join',name:'Racer '+i})));
 const admitted=joined.filter(r=>r.status===200);assert.equal(admitted.length,100);assert.equal(joined.filter(r=>r.status===409).length,10);
 const cookies=admitted.map(r=>r.headers.get('set-cookie').split(';')[0]);
 await Promise.all(cookies.map(async(cookie,i)=>{const ws=new WebSocket('ws://127.0.0.1:3419/ws',{origin,headers:{Cookie:cookie}});sockets.push(ws);ws.on('message',raw=>{const message=JSON.parse(raw.toString());if(message.type==='state'){states.set(ws,message);const progress=message.players.find(p=>p.id==='you')?.progress;if(progress&&observedProgress.get(ws)!==progress&&sentAt.has(progress)){latencies.push(Date.now()-sentAt.get(progress));observedProgress.set(ws,progress);}}else if(message.type!=='pong')throw Error(message.error);});await once(ws,'open');}));
 await waitFor(()=>states.size===100&&[...states.values()].every(s=>s.players.every(p=>p.online)),'100 sockets did not receive the room roster');
 assert.ok(sockets.every(ws=>ws.extensions.includes('permessage-deflate')));
 const probe=sockets[0];probe.send(JSON.stringify({type:'ping',sentAt:Date.now()}));
 const bad=new WebSocket('ws://127.0.0.1:3419/ws',{origin:'https://evil.example'});bad.on('error',()=>{});await new Promise(resolve=>bad.on('close',resolve));
 const login=await post({action:'admin',password:'isolated-test-host'});assert.equal(login.status,200);const hostCookie=login.headers.get('set-cookie').split(';')[0];
 assert.equal((await post({action:'start'},hostCookie)).status,200);
 await waitFor(()=>[...states.values()].every(s=>s.startAt!==null),'Countdown was not pushed to every client');
 const start=[...states.values()][0].startAt;assert.equal(new Set([...states.values()].map(s=>s.startAt)).size,1);
 assert.equal((await post({action:'join',name:'Late'})).status,409);
 await new Promise(r=>setTimeout(r,Math.max(0,start-Date.now()+100)));
 const originalPassage=[...states.values()][0].passage;assert.equal(originalPassage.length,261);assert.equal(new Set([...states.values()].map(s=>s.passage)).size,1);
 const text=originalPassage.slice(0,25);const began=Date.now();
 for(let i=1;i<=text.length;i++){sentAt.set(i,Date.now());for(const ws of sockets)ws.send(JSON.stringify({action:'progress',round:1,text:text.slice(0,i),strokes:i}));await new Promise(r=>setTimeout(r,100));}
 await waitFor(()=>[...states.values()].every(s=>s.players.every(p=>p.progress===text.length)),'Progress did not reach all 100 clients');
 assert.equal([...states.values()].every(s=>s.joined),true);
 const sorted=latencies.sort((a,b)=>a-b);const p95=sorted[Math.floor(sorted.length*.95)];assert.ok(p95<500,`Live update latency is too high: ${p95}ms`);console.log(`100-player update latency: p95 ${p95}ms over ${sorted.length} observed updates.`);
 assert.equal((await post({action:'finish'})).status,403);
 assert.equal((await post({action:'finish'},hostCookie)).status,200);
 await waitFor(()=>[...states.values()].every(s=>s.endedAt!==null),'Host finish did not reach all clients');
 const end=[...states.values()][0].endedAt;assert.equal(new Set([...states.values()].map(s=>s.endedAt)).size,1);console.log('PASS: host finish froze all 100 clients at the same end time.');
 const late=once(sockets[0],'message');sockets[0].send(JSON.stringify({action:'progress',round:1,text:text+' Again',strokes:31}));assert.equal(JSON.parse((await late)[0]).type,'state');
 assert.equal((await post({action:'restart'})).status,403);
 assert.equal((await post({action:'restart'},hostCookie)).status,200);
 await waitFor(()=>[...states.values()].every(s=>s.round===2&&s.startAt===null&&s.players.length===100&&s.players.every(p=>p.progress===0&&p.finished_at===null)),'Restart did not reset every client');
 assert.equal(new Set([...states.values()].map(s=>s.passage)).size,1);assert.notEqual([...states.values()][0].passage,originalPassage);assert.equal([...states.values()][0].passage.length,261);
 console.log('PASS: host-only restart reset all 100 connected players and kept them joined.');
 const departing=sockets[0];departing.close();await once(departing,'close');states.delete(departing);await waitFor(()=>[...states.values()].every(s=>s.players.filter(p=>p.online).length===99),'Leaving player was not shown as away');
 console.log('PASS: participant presence changed from 100 to 99 online without losing the room roster.');
 console.log(`PASS: exactly 100 of 110 joined; 100 live sockets shared countdown and 2,500 progress updates in ${Date.now()-began}ms; unauthorized starts, cross-origin sockets and late joins rejected.`);
}finally{
 for(const ws of sockets)ws.terminate();server.kill('SIGTERM');await once(server,'exit');rmSync(temp,{recursive:true,force:true});
}
