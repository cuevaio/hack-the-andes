import {test} from 'node:test';
import {DatabaseSync} from 'node:sqlite';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {Race} from '../engine.mjs';
import {passage,evaluateTyping,raceMetrics} from '../race.mjs';
test('one battle admits 100, locks at countdown, scores typing and restores after restart',()=>{
 const dir=mkdtempSync(join(tmpdir(),'typebattle-'));let now=100000;const path=join(dir,'race.sqlite');let race=new Race(path,{now:()=>now});
 try{
  assert.throws(()=>race.start(),/At least one/);const ids=Array.from({length:100},(_,i)=>race.join('Racer '+i));
  assert.equal(race.join('Same player',ids[0]),ids[0]);assert.throws(()=>race.join('Overflow'),/full/);race.start();assert.equal(race.snapshot().startAt,105000);assert.throws(()=>race.start(),/already/);assert.throws(()=>race.progress(ids[0],'Speed',5,1),/not running/);
  now=105100;race.progress(ids[0],'Speedx',6,1);race.progress(ids[1],'Speed is ',9,1);assert.equal(race.snapshot(ids[1]).players[0].id,'you');assert.equal(race.snapshot(ids[0]).players.find(p=>p.id==='you').progress,6);
  now=106000;race.progress(ids[1],passage,passage.length,1);const finish=race.snapshot(ids[1]).players[0].finished_at;assert.equal(finish,106000);
  now=107000;race.progress(ids[0],passage,passage.length,1);assert.equal(race.snapshot(ids[1]).players[0].id,'you');
  race.close();race=new Race(path,{now:()=>now});assert.equal(race.snapshot().players.length,100);assert.equal(race.startAt(),105000);assert.throws(()=>race.join('Late'),/started/);
  now=195000;assert.throws(()=>race.progress(ids[2],'Speed',5,1),/not running/);assert.equal(race.snapshot(ids[1]).players[0].finished_at,finish);
 }finally{race.close();rmSync(dir,{recursive:true,force:true});}
});

test('restart retains players, clears scores, survives reopening and ignores old-round updates',()=>{
 const dir=mkdtempSync(join(tmpdir(),'typebattle-reset-'));const path=join(dir,'race.sqlite');let now=100000;let race=new Race(path,{now:()=>now});
 try{
  const id=race.join('Racer');race.start();now=106000;race.progress(id,passage,passage.length,1);assert.equal(race.snapshot(id).players[0].finished_at,106000);
  race.restart();let state=race.snapshot(id);assert.equal(state.round,2);assert.equal(state.startAt,null);assert.equal(state.joined,true);assert.equal(state.players.length,1);assert.deepEqual(state.players[0],{id:'you',name:'Racer',progress:0,correct:0,strokes:0,finished_at:null});
  race.join('New player');race.start();now=112000;race.progress(id,passage,passage.length,1);assert.equal(race.snapshot(id).players[0].progress,0);race.progress(id,'Speed',5,2);assert.equal(race.snapshot(id).players[0].progress,5);
  race.close();race=new Race(path,{now:()=>now});assert.equal(race.round(),2);assert.equal(race.snapshot(id).joined,true);race.restart();assert.equal(race.snapshot(id).players.find(p=>p.id==='you').progress,0);
 }finally{race.close();rmSync(dir,{recursive:true,force:true});}
});

test('existing databases gain a round number without resetting the current race',()=>{
 const dir=mkdtempSync(join(tmpdir(),'typebattle-migration-'));const path=join(dir,'race.sqlite');const old=new DatabaseSync(path);
 old.exec('CREATE TABLE game(id INTEGER PRIMARY KEY CHECK(id=1),start_at INTEGER); INSERT INTO game VALUES(1,100000); CREATE TABLE players(id TEXT PRIMARY KEY,name TEXT NOT NULL,progress INTEGER NOT NULL DEFAULT 0,strokes INTEGER NOT NULL DEFAULT 0,finished_at INTEGER,updated_at INTEGER NOT NULL);');old.prepare('INSERT INTO players VALUES(?,?,?,?,?,?)').run('legacy','Existing player',10,10,null,100000);old.close();
 const race=new Race(path);try{assert.equal(race.startAt(),100000);assert.equal(race.round(),1);assert.equal(race.snapshot('legacy').players[0].correct,10);assert.equal(race.snapshot('legacy').players[0].progress,10);}finally{race.close();rmSync(dir,{recursive:true,force:true});}
});

test('typing continues after an error and precision affects the ranking',()=>{
 const dir=mkdtempSync(join(tmpdir(),'typebattle-precision-'));let now=100000;const race=new Race(join(dir,'race.sqlite'),{now:()=>now});
 try{
  const typo=race.join('Typo');const accurate=race.join('Accurate');race.start();now=165000;
  race.progress(typo,'Xpeed is a',10,1);
  let player=race.snapshot(typo).players.find(p=>p.id==='you');
  assert.equal(player.progress,10);assert.equal(player.correct,9);
  race.progress(accurate,'Speed is a',10,1);
  assert.equal(race.snapshot(accurate).players[0].id,'you');
  const errors='X'+passage.slice(1);race.progress(typo,errors,passage.length,1);
  player=race.snapshot(typo).players.find(p=>p.id==='you');
  assert.equal(player.progress,261);assert.equal(player.correct,260);assert.equal(player.finished_at,165000);
 }finally{race.close();rmSync(dir,{recursive:true,force:true});}
});

test('net speed counts later correct letters and penalizes corrected mistakes',()=>{
 assert.equal(passage.length,261);
 assert.deepEqual(evaluateTyping('Xpeed is a',10),{progress:10,correct:9,strokes:10});
 assert.deepEqual(raceMetrics({progress:10,correct:9,strokes:10,finished_at:null},100000,160000),{accuracy:0.9,netWpm:1.8});
 assert.deepEqual(raceMetrics({progress:10,correct:10,strokes:20,finished_at:null},100000,160000),{accuracy:0.5,netWpm:1});
 assert.deepEqual(raceMetrics({progress:10,correct:0,strokes:10,finished_at:null},100000,160000),{accuracy:0,netWpm:0});
});

test('host finish freezes standings, rejects late typing, persists and resets cleanly',()=>{
 const dir=mkdtempSync(join(tmpdir(),'typebattle-finish-'));const path=join(dir,'race.sqlite');let now=100000;let race=new Race(path,{now:()=>now});
 try{
  assert.throws(()=>race.finish(),/not started/);const id=race.join('Racer');race.start();assert.throws(()=>race.finish(),/not started/);
  now=115000;race.progress(id,'Speed is a',10,1);race.finish();assert.equal(race.snapshot(id).endedAt,115000);assert.equal(race.snapshot(id).players[0].finished_at,null);
  now=150000;race.finish();assert.equal(race.endedAt(),115000);assert.throws(()=>race.progress(id,passage,261,1),/not running/);
  assert.deepEqual(raceMetrics(race.snapshot(id).players[0],105000,race.endedAt()),{accuracy:1,netWpm:12});
  race.close();race=new Race(path,{now:()=>now});assert.equal(race.endedAt(),115000);race.restart();assert.equal(race.endedAt(),null);assert.equal(race.snapshot(id).joined,true);
 }finally{race.close();rmSync(dir,{recursive:true,force:true});}
});


test('each finisher keeps their own elapsed time while unfinished players use the deadline',()=>{
 const dir=mkdtempSync(join(tmpdir(),'typebattle-personal-time-'));let now=100000;
 const race=new Race(join(dir,'race.sqlite'),{now:()=>now});
 try{
  const fast=race.join('Fast');const slow=race.join('Slow');const incomplete=race.join('Incomplete');race.start();
  now=135000;race.progress(fast,passage,261,1);race.progress(incomplete,passage.slice(0,100),100,1);
  const score=id=>{const state=race.snapshot(id);return raceMetrics(state.players.find(p=>p.id==='you'),state.startAt,Math.min(state.now,state.endedAt??Infinity)).netWpm;};
  assert.equal(score(fast),104.4);
  now=165000;race.progress(slow,passage,261,1);
  assert.equal(score(fast),104.4);assert.equal(score(slow),52.2);
  now=195000;
  assert.equal(score(fast),104.4);assert.equal(score(slow),52.2);assert.equal(score(incomplete),100/5/1.5);
  now=250000;
  assert.equal(score(fast),104.4);assert.equal(score(slow),52.2);assert.equal(score(incomplete),100/5/1.5);
 }finally{race.close();rmSync(dir,{recursive:true,force:true});}
});

test('host ending the race does not replace a completed player finish time',()=>{
 const dir=mkdtempSync(join(tmpdir(),'typebattle-finish-time-'));let now=100000;
 const race=new Race(join(dir,'race.sqlite'),{now:()=>now});
 try{
  const finished=race.join('Finished');const incomplete=race.join('Incomplete');race.start();
  now=135000;race.progress(finished,passage,261,1);race.progress(incomplete,passage.slice(0,100),100,1);
  now=165000;race.finish();now=250000;
  const state=race.snapshot();
  assert.equal(raceMetrics(state.players.find(p=>p.name==='Finished'),state.startAt,state.endedAt).netWpm,104.4);
  assert.equal(raceMetrics(state.players.find(p=>p.name==='Incomplete'),state.startAt,state.endedAt).netWpm,20);
 }finally{race.close();rmSync(dir,{recursive:true,force:true});}
});
