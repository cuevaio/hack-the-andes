import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {Race} from '../engine.mjs';
import {passage} from '../race.mjs';
test('one battle admits 100, locks at countdown, scores correct prefixes and restores after restart',()=>{
 const dir=mkdtempSync(join(tmpdir(),'typebattle-'));let now=100000;const path=join(dir,'race.sqlite');let race=new Race(path,{now:()=>now});
 try{
  assert.throws(()=>race.start(),/At least one/);const ids=Array.from({length:100},(_,i)=>race.join('Racer '+i));
  assert.equal(race.join('Same player',ids[0]),ids[0]);assert.throws(()=>race.join('Overflow'),/full/);race.start();assert.equal(race.snapshot().startAt,105000);assert.throws(()=>race.start(),/already/);assert.throws(()=>race.progress(ids[0],'Speed',5),/not running/);
  now=105100;race.progress(ids[0],'Speedx',6);race.progress(ids[1],'Speed is ',9);assert.equal(race.snapshot(ids[1]).players[0].id,'you');assert.equal(race.snapshot(ids[0]).players.find(p=>p.id==='you').progress,5);
  now=106000;race.progress(ids[1],passage,passage.length);const finish=race.snapshot(ids[1]).players[0].finished_at;assert.equal(finish,106000);
  now=107000;race.progress(ids[0],passage,passage.length);assert.equal(race.snapshot(ids[1]).players[0].id,'you');
  race.close();race=new Race(path,{now:()=>now});assert.equal(race.snapshot().players.length,100);assert.equal(race.startAt(),105000);assert.throws(()=>race.join('Late'),/started/);
  now=195000;assert.throws(()=>race.progress(ids[2],'Speed',5),/not running/);assert.equal(race.snapshot(ids[1]).players[0].finished_at,finish);
 }finally{race.close();rmSync(dir,{recursive:true,force:true});}
});
