import {test} from 'node:test';
import {DatabaseSync} from 'node:sqlite';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {Race} from '../engine.mjs';
import {passage} from '../race.mjs';
test('one battle admits 100, locks at countdown, scores correct prefixes and restores after restart',()=>{
 const dir=mkdtempSync(join(tmpdir(),'typebattle-'));let now=100000;const path=join(dir,'race.sqlite');let race=new Race(path,{now:()=>now});
 try{
  assert.throws(()=>race.start(),/At least one/);const ids=Array.from({length:100},(_,i)=>race.join('Racer '+i));
  assert.equal(race.join('Same player',ids[0]),ids[0]);assert.throws(()=>race.join('Overflow'),/full/);race.start();assert.equal(race.snapshot().startAt,105000);assert.throws(()=>race.start(),/already/);assert.throws(()=>race.progress(ids[0],'Speed',5,1),/not running/);
  now=105100;race.progress(ids[0],'Speedx',6,1);race.progress(ids[1],'Speed is ',9,1);assert.equal(race.snapshot(ids[1]).players[0].id,'you');assert.equal(race.snapshot(ids[0]).players.find(p=>p.id==='you').progress,5);
  now=106000;race.progress(ids[1],passage,passage.length,1);const finish=race.snapshot(ids[1]).players[0].finished_at;assert.equal(finish,106000);
  now=107000;race.progress(ids[0],passage,passage.length,1);assert.equal(race.snapshot(ids[1]).players[0].id,'you');
  race.close();race=new Race(path,{now:()=>now});assert.equal(race.snapshot().players.length,100);assert.equal(race.startAt(),105000);assert.throws(()=>race.join('Late'),/started/);
  now=195000;assert.throws(()=>race.progress(ids[2],'Speed',5,1),/not running/);assert.equal(race.snapshot(ids[1]).players[0].finished_at,finish);
 }finally{race.close();rmSync(dir,{recursive:true,force:true});}
});

test('restart retains players, clears scores, survives reopening and ignores old-round updates',()=>{
 const dir=mkdtempSync(join(tmpdir(),'typebattle-reset-'));const path=join(dir,'race.sqlite');let now=100000;let race=new Race(path,{now:()=>now});
 try{
  const id=race.join('Racer');race.start();now=106000;race.progress(id,passage,passage.length,1);assert.equal(race.snapshot(id).players[0].finished_at,106000);
  race.restart();let state=race.snapshot(id);assert.equal(state.round,2);assert.equal(state.startAt,null);assert.equal(state.joined,true);assert.equal(state.players.length,1);assert.deepEqual(state.players[0],{id:'you',name:'Racer',progress:0,strokes:0,finished_at:null});
  race.join('New player');race.start();now=112000;race.progress(id,passage,passage.length,1);assert.equal(race.snapshot(id).players[0].progress,0);race.progress(id,'Speed',5,2);assert.equal(race.snapshot(id).players[0].progress,5);
  race.close();race=new Race(path,{now:()=>now});assert.equal(race.round(),2);assert.equal(race.snapshot(id).joined,true);race.restart();assert.equal(race.snapshot(id).players.find(p=>p.id==='you').progress,0);
 }finally{race.close();rmSync(dir,{recursive:true,force:true});}
});

test('existing databases gain a round number without resetting the current race',()=>{
 const dir=mkdtempSync(join(tmpdir(),'typebattle-migration-'));const path=join(dir,'race.sqlite');const old=new DatabaseSync(path);
 old.exec('CREATE TABLE game(id INTEGER PRIMARY KEY CHECK(id=1),start_at INTEGER); INSERT INTO game VALUES(1,100000);');old.close();
 const race=new Race(path);try{assert.equal(race.startAt(),100000);assert.equal(race.round(),1);}finally{race.close();rmSync(dir,{recursive:true,force:true});}
});
