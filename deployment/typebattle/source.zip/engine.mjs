import { DatabaseSync } from 'node:sqlite';
import { randomUUID } from 'node:crypto';
import { duration, passage } from './race.mjs';
export class RaceError extends Error { constructor(message,status=409){super(message);this.status=status;} }
export class Race {
 constructor(path,{now=Date.now}={}) {
  this.now=now; this.db=new DatabaseSync(path);
  this.db.exec(`PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL; CREATE TABLE IF NOT EXISTS game (id INTEGER PRIMARY KEY CHECK(id=1), start_at INTEGER); INSERT OR IGNORE INTO game(id) VALUES(1); CREATE TABLE IF NOT EXISTS players (id TEXT PRIMARY KEY, name TEXT NOT NULL, progress INTEGER NOT NULL DEFAULT 0, strokes INTEGER NOT NULL DEFAULT 0, finished_at INTEGER, updated_at INTEGER NOT NULL);`);
 }
 startAt(){return this.db.prepare('SELECT start_at FROM game WHERE id=1').get().start_at;}
 player(id){return id ? this.db.prepare('SELECT * FROM players WHERE id=?').get(id) : undefined;}
 join(name,existingId){
  if(this.player(existingId))return existingId;
  if(this.startAt()!==null)throw new RaceError('The race has already started.');
  if(this.db.prepare('SELECT COUNT(*) AS count FROM players').get().count>=100)throw new RaceError('The lobby is full.');
  const id=randomUUID();this.db.prepare('INSERT INTO players (id,name,updated_at) VALUES (?,?,?)').run(id,name,this.now());return id;
 }
 start(){if(this.startAt()!==null)throw new RaceError('The battle has already started.');if(!this.db.prepare('SELECT id FROM players LIMIT 1').get())throw new RaceError('At least one player must join first.');this.db.prepare('UPDATE game SET start_at=? WHERE id=1').run(this.now()+5000);}
 progress(id,text,strokes){
  const player=this.player(id);if(!player)throw new RaceError('Join the lobby first.',403);
  const now=this.now(),start=this.startAt();if(start===null||now<start||now>=start+duration*1000)throw new RaceError('The race is not running.');
  if(player.finished_at!==null)return;
  let correct=0;while(correct<text.length&&text[correct]===passage[correct])correct++;
  this.db.prepare('UPDATE players SET progress=?,strokes=?,finished_at=?,updated_at=? WHERE id=?').run(correct,Math.max(strokes,text.length,player.strokes),correct===passage.length?now:null,now,id);
 }
 snapshot(id,isAdmin=false){
  const players=this.db.prepare('SELECT * FROM players ORDER BY progress DESC, finished_at ASC, updated_at ASC, id ASC').all();
  return {startAt:this.startAt(),now:this.now(),players:players.map(p=>({id:p.id===id?'you':null,name:p.name,progress:p.progress,strokes:p.strokes,finished_at:p.finished_at})),joined:players.some(p=>p.id===id),isAdmin};
 }
 close(){this.db.close();}
}
