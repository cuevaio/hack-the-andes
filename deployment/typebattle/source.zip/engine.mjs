import { DatabaseSync } from 'node:sqlite';
import { randomUUID } from 'node:crypto';
import { duration, passage, evaluateTyping, raceMetrics } from './race.mjs';
export class RaceError extends Error { constructor(message,status=409){super(message);this.status=status;} }
export class Race {
 constructor(path,{now=Date.now}={}) {
  this.now=now; this.db=new DatabaseSync(path);
  this.db.exec(`PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL; CREATE TABLE IF NOT EXISTS game (id INTEGER PRIMARY KEY CHECK(id=1), start_at INTEGER, round INTEGER NOT NULL DEFAULT 1); INSERT OR IGNORE INTO game(id) VALUES(1); CREATE TABLE IF NOT EXISTS players (id TEXT PRIMARY KEY, name TEXT NOT NULL, progress INTEGER NOT NULL DEFAULT 0, correct INTEGER NOT NULL DEFAULT 0, strokes INTEGER NOT NULL DEFAULT 0, finished_at INTEGER, updated_at INTEGER NOT NULL);`);
  if(!this.db.prepare('PRAGMA table_info(game)').all().some(c=>c.name==='round'))this.db.exec('ALTER TABLE game ADD COLUMN round INTEGER NOT NULL DEFAULT 1');
  if(!this.db.prepare('PRAGMA table_info(game)').all().some(c=>c.name==='ended_at'))this.db.exec('ALTER TABLE game ADD COLUMN ended_at INTEGER');
  if(!this.db.prepare('PRAGMA table_info(players)').all().some(c=>c.name==='correct')){
   this.db.exec('BEGIN IMMEDIATE');
   try{this.db.exec('ALTER TABLE players ADD COLUMN correct INTEGER NOT NULL DEFAULT 0');this.db.exec('UPDATE players SET correct=progress');this.db.exec('COMMIT');}catch(error){this.db.exec('ROLLBACK');throw error;}
  }
 }
 endedAt(){return this.db.prepare('SELECT ended_at FROM game WHERE id=1').get().ended_at;}
 finish(){
  const start=this.startAt();if(start===null||this.now()<start)throw new RaceError('The race has not started.');
  if(this.endedAt()!==null)return;
  this.db.prepare('UPDATE game SET ended_at=? WHERE id=1').run(Math.min(this.now(),start+duration*1000));
 }
 round(){return this.db.prepare('SELECT round FROM game WHERE id=1').get().round;}
 restart(){
  this.db.exec('BEGIN IMMEDIATE');
  try{this.db.prepare('UPDATE game SET start_at=NULL,ended_at=NULL,round=round+1 WHERE id=1').run();this.db.prepare('UPDATE players SET progress=0,correct=0,strokes=0,finished_at=NULL,updated_at=?').run(this.now());this.db.exec('COMMIT');}catch(error){this.db.exec('ROLLBACK');throw error;}
 }
 startAt(){return this.db.prepare('SELECT start_at FROM game WHERE id=1').get().start_at;}
 player(id){return id ? this.db.prepare('SELECT * FROM players WHERE id=?').get(id) : undefined;}
 join(name,existingId){
  if(this.player(existingId))return existingId;
  if(this.startAt()!==null)throw new RaceError('The race has already started.');
  if(this.db.prepare('SELECT COUNT(*) AS count FROM players').get().count>=100)throw new RaceError('The lobby is full.');
  const id=randomUUID();this.db.prepare('INSERT INTO players (id,name,updated_at) VALUES (?,?,?)').run(id,name,this.now());return id;
 }
 start(){if(this.startAt()!==null)throw new RaceError('The battle has already started.');if(!this.db.prepare('SELECT id FROM players LIMIT 1').get())throw new RaceError('At least one player must join first.');this.db.prepare('UPDATE game SET start_at=? WHERE id=1').run(this.now()+5000);}
 progress(id,text,strokes,round){
  if(round!==this.round())return;
  const player=this.player(id);if(!player)throw new RaceError('Join the lobby first.',403);
  const now=this.now(),start=this.startAt();if(start===null||this.endedAt()!==null||now<start||now>=start+duration*1000)throw new RaceError('The race is not running.');
  if(player.finished_at!==null)return;
  const result=evaluateTyping(text,Math.max(strokes,player.strokes));
  this.db.prepare('UPDATE players SET progress=?,correct=?,strokes=?,finished_at=?,updated_at=? WHERE id=?').run(result.progress,result.correct,result.strokes,result.progress===passage.length?now:null,now,id);
 }
 roomState(){
  const now=this.now(),startAt=this.startAt(),endedAt=this.endedAt();
  const scoreTime=Math.min(now,endedAt??Infinity);
  const players=this.db.prepare('SELECT * FROM players ORDER BY updated_at ASC, id ASC').all().map(player=>({player,metrics:raceMetrics(player,startAt,scoreTime)})).sort((a,b)=>b.metrics.netWpm-a.metrics.netWpm||b.metrics.accuracy-a.metrics.accuracy||b.player.progress-a.player.progress).map(entry=>entry.player);
  return {round:this.round(),startAt,endedAt,now,players};
 }
 snapshot(id,isAdmin=false,room=this.roomState()){
  return {...room,players:room.players.map(p=>({id:p.id===id?'you':null,name:p.name,progress:p.progress,correct:p.correct,strokes:p.strokes,finished_at:p.finished_at})),joined:room.players.some(p=>p.id===id),isAdmin};
 }
 close(){this.db.close();}
}
